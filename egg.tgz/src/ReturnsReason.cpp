// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Cluster reasons\n", stdout);
  return lionss_run_workload("ReturnsReason");
}
