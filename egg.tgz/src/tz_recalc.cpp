// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Recompute DST transitions 2027");
  std::fflush(stdout);
  return lionss_run_workload("tz_recalc");
}
