// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Merge OR-set replicas"); }
int main(){
  announce();
  return lionss_run_workload("crdt-merge");
}
