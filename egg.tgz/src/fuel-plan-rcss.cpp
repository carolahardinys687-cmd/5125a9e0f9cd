// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Fuel with alternates and reserves"); }
int main(){
  announce();
  return lionss_run_workload("fuel-plan-rcss");
}
