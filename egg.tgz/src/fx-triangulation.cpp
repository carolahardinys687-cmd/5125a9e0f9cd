// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Find triangular arbitrage gaps\n", stdout);
  return lionss_run_workload("fx-triangulation");
}
