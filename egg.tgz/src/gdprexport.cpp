// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Assemble subject access bundle\n", stdout);
  return lionss_run_workload("gdprexport");
}
