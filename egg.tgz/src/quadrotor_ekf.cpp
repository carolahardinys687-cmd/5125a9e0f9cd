// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("EKF attitude estimate\n", stdout);
  return lionss_run_workload("quadrotor_ekf");
}
