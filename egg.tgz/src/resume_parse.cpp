// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Extract roles and skills\n", stdout);
  return lionss_run_workload("resume_parse");
}
