// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Time evaluation of 200 attrs"); }
int main(){
  announce();
  return lionss_run_workload("NixEvalTime");
}
