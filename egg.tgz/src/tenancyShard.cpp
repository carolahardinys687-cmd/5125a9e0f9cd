// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Rebalance tenants across 8 shards"); }
int main(){
  announce();
  return lionss_run_workload("tenancyShard");
}
