// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Content-defined chunking"); }
int main(){
  announce();
  return lionss_run_workload("dedupe_blocks");
}
