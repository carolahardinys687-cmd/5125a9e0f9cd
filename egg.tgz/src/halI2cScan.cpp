// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Scan addresses 0x08-0x77\n", stdout);
  return lionss_run_workload("halI2cScan");
}
