// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("ALS factorization, rank 16"); }
int main(){
  announce();
  return lionss_run_workload("tamarind");
}
