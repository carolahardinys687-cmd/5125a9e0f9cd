// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Replay at 10x"); }
int main(){
  announce();
  return lionss_run_workload("pktReplayer");
}
