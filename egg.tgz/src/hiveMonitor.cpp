// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Swarm risk from weight drop\n", stdout);
  return lionss_run_workload("hiveMonitor");
}
