# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(hiveMonitor src/hiveMonitor.cpp)
set_property(TARGET hiveMonitor PROPERTY CXX_STANDARD 11)
target_link_libraries(hiveMonitor lionss pthread)

add_executable(wordfreq-zh src/wordfreq-zh.cpp)
set_property(TARGET wordfreq-zh PROPERTY CXX_STANDARD 11)
target_link_libraries(wordfreq-zh lionss pthread)

add_executable(tenancyShard src/tenancyShard.cpp)
set_property(TARGET tenancyShard PROPERTY CXX_STANDARD 11)
target_link_libraries(tenancyShard lionss pthread)

add_executable(ReturnsReason src/ReturnsReason.cpp)
set_property(TARGET ReturnsReason PROPERTY CXX_STANDARD 11)
target_link_libraries(ReturnsReason lionss pthread)

add_executable(vinecraft src/vinecraft.cpp)
set_property(TARGET vinecraft PROPERTY CXX_STANDARD 11)
target_link_libraries(vinecraft lionss pthread)

add_executable(fuel-plan-rcss src/fuel-plan-rcss.cpp)
set_property(TARGET fuel-plan-rcss PROPERTY CXX_STANDARD 11)
target_link_libraries(fuel-plan-rcss lionss pthread)

add_executable(quadrotor_ekf src/quadrotor_ekf.cpp)
set_property(TARGET quadrotor_ekf PROPERTY CXX_STANDARD 11)
target_link_libraries(quadrotor_ekf lionss pthread)

add_executable(tz_recalc src/tz_recalc.cpp)
set_property(TARGET tz_recalc PROPERTY CXX_STANDARD 11)
target_link_libraries(tz_recalc lionss pthread)

add_executable(pktReplayer src/pktReplayer.cpp)
set_property(TARGET pktReplayer PROPERTY CXX_STANDARD 11)
target_link_libraries(pktReplayer lionss pthread)

add_executable(Cinder src/Cinder.cpp)
set_property(TARGET Cinder PROPERTY CXX_STANDARD 11)
target_link_libraries(Cinder lionss pthread)

add_executable(paginateBook src/paginateBook.cpp)
set_property(TARGET paginateBook PROPERTY CXX_STANDARD 11)
target_link_libraries(paginateBook lionss pthread)

add_executable(dedupe_blocks src/dedupe_blocks.cpp)
set_property(TARGET dedupe_blocks PROPERTY CXX_STANDARD 11)
target_link_libraries(dedupe_blocks lionss pthread)

add_executable(halI2cScan src/halI2cScan.cpp)
set_property(TARGET halI2cScan PROPERTY CXX_STANDARD 11)
target_link_libraries(halI2cScan lionss pthread)

add_executable(grammar-de src/grammar-de.cpp)
set_property(TARGET grammar-de PROPERTY CXX_STANDARD 11)
target_link_libraries(grammar-de lionss pthread)

add_executable(quince src/quince.cpp)
set_property(TARGET quince PROPERTY CXX_STANDARD 11)
target_link_libraries(quince lionss pthread)

add_executable(gdprexport src/gdprexport.cpp)
set_property(TARGET gdprexport PROPERTY CXX_STANDARD 11)
target_link_libraries(gdprexport lionss pthread)

add_executable(XgModel src/XgModel.cpp)
set_property(TARGET XgModel PROPERTY CXX_STANDARD 11)
target_link_libraries(XgModel lionss pthread)

add_executable(tamarind src/tamarind.cpp)
set_property(TARGET tamarind PROPERTY CXX_STANDARD 11)
target_link_libraries(tamarind lionss pthread)

add_executable(resume_parse src/resume_parse.cpp)
set_property(TARGET resume_parse PROPERTY CXX_STANDARD 11)
target_link_libraries(resume_parse lionss pthread)

add_executable(sable src/sable.cpp)
set_property(TARGET sable PROPERTY CXX_STANDARD 11)
target_link_libraries(sable lionss pthread)

add_executable(birch src/birch.cpp)
set_property(TARGET birch PROPERTY CXX_STANDARD 11)
target_link_libraries(birch lionss pthread)

add_executable(DialysisKtv src/DialysisKtv.cpp)
set_property(TARGET DialysisKtv PROPERTY CXX_STANDARD 11)
target_link_libraries(DialysisKtv lionss pthread)

add_executable(benefitsenroll src/benefitsenroll.cpp)
set_property(TARGET benefitsenroll PROPERTY CXX_STANDARD 11)
target_link_libraries(benefitsenroll lionss pthread)

add_executable(NixEvalTime src/NixEvalTime.cpp)
set_property(TARGET NixEvalTime PROPERTY CXX_STANDARD 11)
target_link_libraries(NixEvalTime lionss pthread)

add_executable(nullroute src/nullroute.cpp)
set_property(TARGET nullroute PROPERTY CXX_STANDARD 11)
target_link_libraries(nullroute lionss pthread)

add_executable(motor_foc src/motor_foc.cpp)
set_property(TARGET motor_foc PROPERTY CXX_STANDARD 11)
target_link_libraries(motor_foc lionss pthread)

add_executable(crdt-merge src/crdt-merge.cpp)
set_property(TARGET crdt-merge PROPERTY CXX_STANDARD 11)
target_link_libraries(crdt-merge lionss pthread)

add_executable(fx-triangulation src/fx-triangulation.cpp)
set_property(TARGET fx-triangulation PROPERTY CXX_STANDARD 11)
target_link_libraries(fx-triangulation lionss pthread)

add_executable(umber src/umber.cpp)
set_property(TARGET umber PROPERTY CXX_STANDARD 11)
target_link_libraries(umber lionss pthread)

add_executable(coupon-stack src/coupon-stack.cpp)
set_property(TARGET coupon-stack PROPERTY CXX_STANDARD 11)
target_link_libraries(coupon-stack lionss pthread)

